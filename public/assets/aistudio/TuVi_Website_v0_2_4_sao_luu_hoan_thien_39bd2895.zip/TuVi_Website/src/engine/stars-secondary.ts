import { mod } from './constants.js';
import type { StarPlacement } from './types.js';
const p=(id:string,name:string,branch:number,status:StarPlacement['status']='CANDIDATE_SPEC',scope:'natal'|'annual'='natal'):StarPlacement=>({id,name,branch:mod(branch),status,scope});
export function placeMonthStars(month:number):StarPlacement[] {
  const m=month-1;
  return [p('ta-phu','Tả Phù',4+m,'CANDIDATE_IZTRO'),p('huu-bat','Hữu Bật',10-m,'CANDIDATE_IZTRO'),p('thien-hinh','Thiên Hình',9+m,'CANDIDATE_IZTRO'),p('thien-dieu','Thiên Diêu',1+m,'CANDIDATE_IZTRO'),p('thien-y','Thiên Y',1+m,'CONFLICT'),
    p('thien-vu','Thiên Vu',([5,8,2,11,5,8,2,11,5,8,2,11] as number[])[month-1]!,'CANDIDATE_IZTRO'),
    p('am-sat','Âm Sát',([2,0,10,8,6,4,2,0,10,8,6,4] as number[])[month-1]!,'CANDIDATE_IZTRO'),
    p('thien-nguyet','Thiên Nguyệt',([10,5,4,2,7,3,11,7,2,6,10,2] as number[])[month-1]!,'CANDIDATE_IZTRO')];
}
export function placeHourStars(hourBranch:number):StarPlacement[] {
  return [p('van-xuong','Văn Xương',10-hourBranch,'CANDIDATE_IZTRO'),p('van-khuc','Văn Khúc',4+hourBranch,'CANDIDATE_IZTRO'),p('thai-phu','Thai Phụ',6+hourBranch,'CANDIDATE_IZTRO'),p('phong-cao','Phong Cáo',2+hourBranch,'VERIFIED_TUVIVN')];
}
export function placeDayStars(day:number,taPhuBranch:number,huuBatBranch:number,vanXuongBranch:number,vanKhucBranch:number):StarPlacement[] {
  return [p('tam-thai','Tam Thai',taPhuBranch+day-1,'CANDIDATE_IZTRO'),p('bat-toa','Bát Tọa',huuBatBranch-day+1,'CANDIDATE_IZTRO'),p('an-quang','Ân Quang',vanXuongBranch+day-2,'CANDIDATE_IZTRO'),p('thien-quy','Thiên Quý',vanKhucBranch+day-2,'CANDIDATE_IZTRO')];
}
export function placeYearBranchStars(yearBranch:number,menhBranch:number,thanBranch:number):StarPlacement[] {
  const z=yearBranch;
  const peachByBranch=[9,6,3,0,9,6,3,0,9,6,3,0];
  const hoaCaiByBranch=[4,1,10,7,4,1,10,7,4,1,10,7];
  const kiepSatByBranch=[5,2,11,8,5,2,11,8,5,2,11,8];
  const coQuaByBranch=[{c:2,q:10},{c:2,q:10},{c:5,q:1},{c:5,q:1},{c:5,q:1},{c:8,q:4},{c:8,q:4},{c:8,q:4},{c:11,q:7},{c:11,q:7},{c:11,q:7},{c:2,q:10}];
  const coQua=coQuaByBranch[z]!;
  const thienMaByBranch=[2,11,8,5,2,11,8,5,2,11,8,5];
  return [p('thien-ma','Thiên Mã',thienMaByBranch[z]!,'CANDIDATE_SPEC'),
    p('dao-hoa','Đào Hoa',peachByBranch[z]!,'VERIFIED_TUVIVN'),p('hong-loan','Hồng Loan',mod(3-z),'VERIFIED_TUVIVN'),p('thien-hy','Thiên Hỷ',mod(9-z),'VERIFIED_TUVIVN'),
    p('hoa-cai','Hoa Cái',hoaCaiByBranch[z]!,'CANDIDATE_IZTRO'),p('kiep-sat','Kiếp Sát',kiepSatByBranch[z]!,'CANDIDATE_IZTRO'),
    p('long-tri','Long Trì',4+z,'CANDIDATE_IZTRO'),p('phuong-cac','Phượng Các',10-z,'CANDIDATE_IZTRO'),p('thien-khoc','Thiên Khốc',6-z,'CANDIDATE_IZTRO'),p('thien-hu','Thiên Hư',6+z,'CANDIDATE_IZTRO'),
    p('thien-duc','Thiên Đức',9+z,'CANDIDATE_IZTRO'),p('nguyet-duc','Nguyệt Đức',5+z,'CANDIDATE_IZTRO'),p('thien-khong','Thiên Không',z+1,'VERIFIED_TUVIVN'),
    p('thien-tai','Thiên Tài',menhBranch+z,'CANDIDATE_IZTRO'),p('thien-tho','Thiên Thọ',thanBranch+z,'CANDIDATE_IZTRO'),
    p('co-than','Cô Thần',coQua.c,'VERIFIED_TUVIVN'),p('qua-tu','Quả Tú',coQua.q,'VERIFIED_TUVIVN')];
}
// Thiên Khôi / Thiên Việt theo Can NĂM, bảng do chủ dự án cung cấp (v0.2.2):
// Giáp,Canh: Sửu–Mùi | Ất: Tý–Thân | Bính,Đinh: Hợi–Dậu | Mậu,Kỷ: Mão–Tỵ | Tân: Ngọ–Dần | Nhâm,Quý: Tỵ–Mão.
const KHOI_VIET:Array<[number,number]>=[[1,7],[0,8],[11,9],[11,9],[3,5],[3,5],[1,7],[6,2],[5,3],[5,3]];
// Khớp ảnh Tuvi.vn: Giáp, Ất, Bính, Tân. MÂU THUẪN ảnh Tuvi.vn: Canh (TV-001/007 thấy Ngọ–Dần), Kỷ (TV-003/CORE-03 thấy Tý–Thân),
// Quý (TV-002/LEAP-04 thấy Mão–Tỵ). Chưa có ảnh: Mậu, Đinh, Nhâm.
export const KHOI_VIET_TUVIVN_OBSERVED:Record<number,[number,number]>={0:[1,7],1:[0,8],2:[11,9],5:[0,8],6:[6,2],7:[6,2],9:[3,5]};
const KHOI_VIET_MATCH=new Set([0,1,2,7]);
const KHOI_VIET_CONFLICT=new Set([5,6,9]);
// Quốc Ấn = Lộc Tồn + 8 (Giáp Tuất, Ất Hợi, Bính Sửu, Đinh Dần, Mậu Sửu, Kỷ Dần, Canh Thìn, Tân Tỵ, Nhâm Mùi, Quý Thân).
const QUOC_AN=[10,11,1,2,1,2,4,5,7,8];
const QUOC_AN_VERIFIED_STEMS=new Set([0,1,2,5,6,7,9]);
// Thiên Trù theo Can năm. Quý = Tuất (Tuvi.vn, TV-002 và LEAP-04), KHÔNG phải Hợi như iztro.
const THIEN_TRU=[5,6,0,5,6,8,2,6,9,10];
const THIEN_TRU_VERIFIED_STEMS=new Set([0,1,2,5,6,7,9]);
const unverifiedNote='Chưa có fixture cho Can năm này; dùng bảng nhóm.';
export function placeYearStemStars(yearStem:number):StarPlacement[] {
  const quan=[7,4,5,2,3,9,11,9,10,6];
  const phuc=[9,8,0,11,3,2,6,5,6,5];
  const luuHa=[9,10,7,4,5,6,8,3,11,2];
  const locTon=[2,3,5,6,5,6,8,9,11,0];
  const st=mod(yearStem,10);
  const stat=(set:Set<number>):StarPlacement['status']=>set.has(st)?'VERIFIED_TUVIVN':'CANDIDATE_SPEC';
  const kv=(id:string,name:string,i:0|1):StarPlacement=>{
    const star=p(id,name,KHOI_VIET[st]![i],KHOI_VIET_MATCH.has(st)?'VERIFIED_TUVIVN':KHOI_VIET_CONFLICT.has(st)?'CONFLICT':'CANDIDATE_SPEC');
    if(KHOI_VIET_CONFLICT.has(st)){const o=KHOI_VIET_TUVIVN_OBSERVED[st]![i];return {...star,note:`Bảng dự án khác ảnh Tuvi.vn đã quan sát (chi ${o}).`};}
    return KHOI_VIET_MATCH.has(st)?star:{...star,note:'Bảng dự án; chưa có ảnh Tuvi.vn cho Can này.'};
  };
  const withNote=(star:StarPlacement,set:Set<number>):StarPlacement=>set.has(st)?star:{...star,note:unverifiedNote};
  return [p('loc-ton','Lộc Tồn',locTon[st]!,'CANDIDATE_SPEC'),p('thien-quan','Thiên Quan',quan[st]!,'CANDIDATE_SPEC'),p('thien-phuc','Thiên Phúc',phuc[st]!,'CANDIDATE_SPEC'),
    withNote(p('thien-tru','Thiên Trù',THIEN_TRU[st]!,stat(THIEN_TRU_VERIFIED_STEMS)),THIEN_TRU_VERIFIED_STEMS),
    p('luu-ha','Lưu Hà',luuHa[st]!,'CANDIDATE_SPEC'),
    kv('thien-khoi','Thiên Khôi',0),kv('thien-viet','Thiên Việt',1),
    withNote(p('quoc-an','Quốc Ấn',QUOC_AN[st]!,stat(QUOC_AN_VERIFIED_STEMS)),QUOC_AN_VERIFIED_STEMS)];
}
// Thiên Thương / Thiên Sứ: cố định Nô Bộc (Mệnh+5) và Tật Ách (Mệnh+7), KHÔNG đổi chỗ theo âm dương/giới tính.
// Đã khớp đủ 4 tổ hợp: Dương Nam (TV-001), Âm Nam (TV-002), Âm Nữ (TV-004), Dương Nữ (TV-005).
export function placeThuongSu(menhBranch:number):StarPlacement[] {
  return [p('thien-thuong','Thiên Thương',menhBranch+5,'VERIFIED_TUVIVN'),p('thien-su','Thiên Sứ',menhBranch+7,'VERIFIED_TUVIVN')];
}
// Đẩu Quân: từ Thái Tuế (chi năm) đếm nghịch tới tháng sinh, rồi đếm thuận tới giờ sinh.
// Tháng nhuận dùng nguyên số tháng âm (LEAP-04 ngày 16 không nhảy sang tháng sau).
export function placeDauQuan(yearBranch:number,month:number,hourBranch:number):StarPlacement[] {
  return [p('dau-quan','Đẩu Quân',yearBranch-(month-1)+hourBranch,'VERIFIED_TUVIVN')];
}

const BAC_SI_NAMES=['Bác Sĩ','Lực Sĩ','Thanh Long','Tiểu Hao','Tướng Quân','Tấu Thư','Phi Liêm','Hỷ Thần','Bệnh Phù','Đại Hao','Phục Binh','Quan Phủ'];
const TRANG_SINH_NAMES=['Tràng Sinh','Mộc Dục','Quan Đới','Lâm Quan','Đế Vượng','Suy','Bệnh','Tử','Mộ','Tuyệt','Thai','Dưỡng'];
const THAI_TUE_NAMES=['Thái Tuế','Thiếu Dương','Tang Môn','Thiếu Âm','Quan Phù','Tử Phù','Tuế Phá','Long Đức','Bạch Hổ','Phúc Đức','Điếu Khách','Trực Phù'];
const TRANG_SINH_START:Record<number,number>={2:8,3:11,4:5,5:8,6:2};
export function placeBacSiCircle(locTonBranch:number,direction:1|-1):StarPlacement[] {
  return BAC_SI_NAMES.map((name,i)=>p(`bac-si-${i}`,name,locTonBranch+direction*i,'CANDIDATE_SPEC'));
}
export function placeTrangSinhCircle(bureauNumber:number,direction:1|-1):StarPlacement[] {
  const start=TRANG_SINH_START[bureauNumber];
  if(start===undefined) throw new Error(`Cục không hợp lệ: ${bureauNumber}`);
  return TRANG_SINH_NAMES.map((name,i)=>p(`trang-sinh-${i}`,name,start+direction*i,'CANDIDATE_SPEC'));
}
export function placeThaiTueCircle(yearBranch:number):StarPlacement[] {
  return THAI_TUE_NAMES.map((name,i)=>p(`thai-tue-${i}`,name,yearBranch+i,'CANDIDATE_SPEC'));
}
export function placeHoaLinh(yearBranch:number,hourBranch:number):StarPlacement[] {
  const group=Math.floor(yearBranch/3);
  const hoaStart=[1,2,3,9][group]!;
  const linhStart=[3,10,10,10][group]!;
  // Both directions follow the candidate formula in v1.3; unresolved against Tuvi.vn.
  return [p('hoa-tinh','Hỏa Tinh',hoaStart+hourBranch,'CONFLICT'),p('linh-tinh','Linh Tinh',linhStart+hourBranch,'CONFLICT')];
}
