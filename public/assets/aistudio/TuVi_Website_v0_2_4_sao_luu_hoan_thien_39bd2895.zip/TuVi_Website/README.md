# Website Tử Vi — prototype engine + giao diện 4×4

**Phiên bản:** `0.2.4`  
**Cập nhật:** 05/11/2026  
**Trạng thái:** Đang phát triển; chưa release-ready.

## Hiện trạng đã xác minh

- Form nhập ngày dương lịch, giới tính, giờ sinh hoặc không rõ giờ.
- Engine TypeScript hiện có lịch âm Việt Nam UTC+7, Can Chi, an 12 cung, Mệnh/Thân, Cục, 14 chính tinh và một phần sao phụ/tạp diệu.
- Bộ dữ liệu gồm **48 fixture records**: 20 fixture nền và 28 testcase capture Tuvi.vn. Cả 28 ảnh capture hiện hành đã khớp input kế hoạch.
- Đã đối chiếu đầy đủ vị trí 14 chính tinh trên **23 bản đồ** (9 fixture nền + 14 capture).
- Đã sửa các lỗi được fixture chỉ ra: Can cung quay vòng Tý/Sửu, quy tắc tháng nhuận theo ảnh Tuvi.vn, Can Chi giờ Tý muộn 23:00–23:59.
- Những con số trên chỉ xác nhận các trường có trong expected fixture. Chúng **không** xác minh sao phụ, tạp diệu, Tứ Hóa, Tuần/Triệt, sao lưu hoặc toàn bộ công thức Tử Vi.

## Phần còn chưa hoàn thành

- Xác minh placement của phụ tinh, tạp diệu, thần sát và các sao có công thức `candidate` / `conflict`.
- Đã thêm lớp sao lưu niên theo năm xem (Can/Chi), Lưu Tứ Hóa bám lên sao gốc và tích hợp 6 quy tắc bổ sung theo bảng người dùng cung cấp trong v0.2.4. Các quy tắc lưu hiện là candidate, cần đối chiếu fixture Tuvi.vn.
- Đại Hạn, Tiểu Hạn, Lưu nguyệt và việc xác minh Tứ Hóa theo từng tầng vẫn chưa hoàn thiện.
- Hoàn thiện bảng độ sáng Miếu/Vượng/Đắc/Bình/Hãm; nạp âm, Cân Lượng, Lai Nhân Cung.
- Hoàn thiện hai chế độ luận giải, responsive, quan hệ tam hợp/xung chiếu và kiểm thử PDF/browser.
- Chạy Vitest và production build trong môi trường cài đủ dependencies.

Xem **[IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md)** để biết danh sách việc còn lại và thứ tự ưu tiên. Đặc tả công thức có các quy tắc chưa tìm được/chưa xác minh nằm tại `docs/01_HienHanh/TuVi_DacTa_CongThuc_v1_3_TheoDoiCongThucThieu.md`.

## Công nghệ đang chạy

- Vite 6 + TypeScript 5.
- Giao diện thực tế hiện là HTML/CSS + TypeScript thao tác DOM; chưa dùng React/Tailwind/Lucide/Motion như stack mục tiêu trong UI Brief.
- Engine/calendar tách trong `src/engine/` và `src/calendar/`.
- Test dùng Vitest; dữ liệu tại `tests/fixtures/`.
- Lớp sao lưu niên ở `src/engine/stars-annual.ts`; nhập năm xem ở trường “Năm xem (năm âm lịch)”. Xem `docs/01_HienHanh/SAO_LUU_NIEN_v0_2_4.md` để biết các bảng mới và ví dụ 2026.

## Cài đặt và chạy

```bash
npm install
npm run dev
```

Mở `http://localhost:5173`.

## Kiểm tra

```bash
npm run typecheck
npm test
npm run build
```

Chỉ đánh dấu Vitest/build là PASS sau khi chạy thực tế thành công bằng dependencies đã cài. Không dùng manual harness thay thế hai cổng kiểm tra này.

## Cấu trúc dữ liệu quan trọng

```text
src/
  calendar/       # Âm lịch, JDN, Can Chi, giờ địa chi
  engine/         # Mệnh/Thân, Cục, chính tinh, phụ tinh
  catalog/        # Metadata sao và Tứ Hóa
 tests/
  core.test.ts
  manual/         # Input dự kiến và trạng thái thu thập testcase Tuvi.vn
  fixtures/       # 20 fixture nền + 28 fixture capture
 docs/
  01_HienHanh/    # Đặc tả công thức và backlog chưa xác minh
  02_UI/          # UI Brief và ảnh tham chiếu
  03_Fixture_TuviVN/ # Ảnh nguồn, gồm ảnh hiện hành và ảnh được thay thế
 archive/         # Demo, engine cũ và file nguồn lưu trữ
```

## Quy tắc phát triển

- Tuvi.vn là chuẩn đầu ra; iztro chỉ là nguồn tham khảo/candidate.
- Không tự đặt công thức hoặc độ sáng khi chưa có căn cứ.
- Không chuyển `CANDIDATE`, `CONFLICT` hoặc `MISSING_RULE` thành verified nếu chưa có fixture phù hợp.
- Giữ riêng các tầng bản mệnh, Đại Hạn, Lưu niên và Lưu nguyệt; không ghi đè placement giữa các tầng.
- Không đánh dấu release-ready trước khi Vitest và production build chạy thành công.
