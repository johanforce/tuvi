# TuVi Website — tiến độ và backlog còn lại

**Phiên bản:** 0.2.4  
**Cập nhật:** 05/11/2026, sau khi tích hợp bảng quy tắc sao lưu do người dùng cung cấp.  
**Trạng thái tổng thể:** Engine bản mệnh đã có nền tảng và được đối chiếu tốt ở lịch/Can Chi/Mệnh–Thân/Cục/14 chính tinh; các nhóm sao còn lại và vận hạn chưa hoàn thiện. Chưa release-ready.

> Đây là tài liệu tiến độ duy nhất. Các audit/coverage report riêng của các vòng capture đã hoàn tất được bỏ để tránh trùng lặp; dữ liệu nguồn vẫn nằm trong `tests/fixtures/`, `tests/manual/` và `docs/03_Fixture_TuviVN/`.

## 1. Mốc đã đạt — chỉ để xác định baseline

| Hạng mục | Bằng chứng hiện có | Giới hạn |
|---|---|---|
| Fixture Tuvi.vn | 48 records: 20 fixture nền + 28 capture; 28 capture hiện hành khớp input kế hoạch | Mỗi fixture chỉ xác minh các trường có trong expected |
| Lịch âm / Can Chi | Có expected trên các fixture; bao phủ 12 giờ địa chi, 10 Can năm và 10 Can ngày trong tập hợp | Chưa thay thế kiểm thử lịch độc lập 1900–2100 trên 50+ mốc |
| Can cung 12 cung | Có regression test 10 Can × 12 cung, đã sửa vòng qua Tý/Sửu | Cần giữ test khi refactor |
| Tháng nhuận | Đã đối chiếu ngày 15/16 của tháng 2 nhuận 2023 và tháng 6 nhuận 2025; engine giữ số tháng âm trong cả tháng nhuận | Không suy rộng thành mọi ngoại lệ lịch nếu chưa có test biên |
| Giờ Tý muộn | HOUR-02 xác nhận 23:00–23:59 dùng Can ngày kế tiếp để tính Can giờ; Can Chi ngày vẫn là ngày hiện tại | Cần giữ các mốc 22:59/23:00/23:59/00:00/00:59 |
| Mệnh / Thân / Cục | Có expected trên bộ fixture | Cần thêm test độc lập cho các biên/nhóm quy tắc chưa phủ |
| 14 chính tinh | 23 bản đồ đủ 14 sao đã đối chiếu | Không xác minh sao phụ, Tứ Hóa, Tuần/Triệt, độ sáng hoặc sao lưu |

## 2. Việc còn lại — ưu tiên P0

1. **Chạy test và build thực tế:** cài dependencies, chạy `npm run typecheck`, `npm test`, `npm run build`; lưu log PASS/FAIL. Không tính manual harness là thay thế Vitest.
2. **Hoàn thiện expected cho sao ngoài 14 chính tinh:** các ảnh đã có cần được đọc/trích vị trí phụ tinh, tạp diệu, thần sát, Tuần/Triệt và dấu Hóa vào fixture. Hiện 23 map chỉ chứa đủ 14 chính tinh.
3. **Khóa quy tắc còn tranh chấp bằng fixture hiện có trước:** Thiên Khôi/Thiên Việt, Hỏa Tinh/Linh Tinh, Địa Không/Địa Kiếp, Phong Cáo, Thiên Trù, Thiên Thương/Thiên Sứ, Tuần/Triệt/Không Vong.
4. **Mở rộng kiểm thử lịch:** tối thiểu 50 mốc trong 1900–2100 gồm ngày sóc, ngày cuối tháng, Tết, chuyển năm âm và các tháng nhuận; giữ bộ test biên giờ.
5. **Kiểm tra Tứ Hóa bản mệnh:** đối chiếu đủ 10 Can và xác minh đúng ID/vị trí theo Tuvi.vn trước khi nâng trạng thái từ candidate.

## 3. Việc còn lại — P1: hoàn thiện engine an sao

- Bổ sung hoặc xác minh placement còn thiếu trong `src/engine/stars-secondary.ts` và `src/catalog/star-metadata.ts`.
- Danh sách sao có placement chưa đủ hoặc chưa được xác minh gồm: Kình Dương, Đà La, Địa Không, Địa Kiếp, Giải Thần/Nguyệt Giải/Niên Giải, Phá Toái, Thiên Thương, Thiên Sứ, Thiên Khôi, Thiên Việt, Đường Phù và các sao được liệt kê trạng thái `MISSING_RULE` trong đặc tả v1.3.
- Kiểm tra riêng vòng Bác Sĩ, Tràng Sinh, Thái Tuế bản mệnh; phân biệt với vòng Tuế Tiền/Tướng Tiền và các lớp lưu.
- Đã tách `natal` và `annual` cho Tứ Hóa: Lưu Tứ Hóa lấy Can năm xem và bám lên vị trí sao gốc. Chưa có fixture đa năm để xác minh với Tuvi.vn. Đại Hạn/Lưu Nguyệt/Phi Hóa chưa triển khai.
- Xây dựng bảng Miếu/Vượng/Đắc/Bình/Hãm có nguồn. Hiện UI chỉ được hiển thị `?`/chưa xác định khi chưa có căn cứ.
- Hoàn thiện metadata ngũ hành/chữ Hán/alias cho toàn bộ danh mục; không suy đoán dữ liệu còn thiếu.

## 4. Việc còn lại — P1: vận hạn

- Đại Hạn theo Cục, giới tính và âm dương năm; xác minh chiều đi và tuổi khởi hạn.
- Tiểu Hạn theo năm; xác minh quy tắc an cung theo tuổi/năm.
- Đã đưa `viewedYear` vào pipeline, có ô chọn năm xem trong form và hiển thị lớp sao lưu riêng trên lá số.
- v0.2.4 đã code hóa 6 quy tắc trước đó còn chờ: Lưu Thiên Không, Lưu Niên Văn Tinh, Lưu Tuần Không, Lưu Triệt Không, Lưu Văn Xương và Lưu Văn Khúc. Lưu Tuần Không/Triệt Không mỗi sao tạo hai placement ở hai Chi.
- Lưu Niên Văn Tinh dùng Can năm sinh và cố định theo lá số gốc; các sao Lưu Thiên Không/Tuần/Triệt/Văn Xương/Văn Khúc dùng quy tắc năm xem theo bảng người dùng cung cấp.
- Các quy tắc vừa thêm mang trạng thái `CANDIDATE_SPEC`, chưa xác minh độc lập với fixture Tuvi.vn. Cần đối chiếu cặp fixture cùng ngày/giờ/giới tính nhưng khác năm xem, đồng thời kiểm tra riêng năm sinh khác Can để xác nhận Lưu Niên Văn Tinh không đổi theo năm xem.

## 5. Việc còn lại — P2: dữ liệu trung tâm và luận giải

- Nạp âm 60 Hoa Giáp và kiểm tra vị trí hiển thị.
- Cân Lượng: tìm bảng/công thức có nguồn và tạo fixture riêng.
- Lai Nhân Cung: xác minh cách tính của Tuvi.vn bằng nhiều chart.
- Hai chế độ luận giải: (1) tổng quan trọn đời; (2) Đại Hạn/Tiểu Hạn theo năm. Không hiển thị văn bản mock như kết luận thật.
- Bổ sung giải nghĩa sao/cung/cách cục dựa trên dữ liệu đã xác minh; chưa tích hợp AI/API key phía frontend.

## 6. Việc còn lại — P2: giao diện và chất lượng sản phẩm

- Hoàn thiện tương tác tam hợp/xung chiếu, chi tiết sao và hiển thị các tầng vận.
- Responsive mobile: giữ sơ đồ 4×4, hỗ trợ zoom/pan và đọc được nội dung cung.
- Kiểm thử PDF/print và browser thực tế; hiện dùng `window.print()`.
- UI Brief là tài liệu yêu cầu giao diện tham chiếu. Stack thực tế hiện vẫn là HTML/CSS + TypeScript DOM; React/Tailwind/Lucide/Motion chưa được tích hợp.

Chi tiết bảng và ví dụ 2026: `docs/01_HienHanh/SAO_LUU_NIEN_v0_2_4.md`.

## 7. Lệnh xác minh tại máy phát triển

```bash
npm install
npm run typecheck
npm test
npm run build
```

**Release gate:** chỉ coi bản phát hành đạt khi cả ba lệnh `typecheck`, `test`, `build` chạy thành công trên môi trường cài đủ dependencies và không có fixture regression.

## 8. Nguồn dữ liệu và tài liệu cần dùng

- Fixture nền: `tests/fixtures/tuvi-vn-fixtures.json` (20 records).
- Fixture capture: `tests/fixtures/tuvi-vn-captured-20261105.json` (28 records).
- Kế hoạch/input capture và trạng thái từng testcase: `tests/manual/tuvi-vn-capture-cases.json`.
- Ảnh nguồn và ảnh được thay thế: `docs/03_Fixture_TuviVN/captures/`.
- Công thức, trạng thái candidate/conflict/missing và các câu hỏi cần nghiên cứu: `docs/01_HienHanh/TuVi_DacTa_CongThuc_v1_3_TheoDoiCongThucThieu.md`.
- Yêu cầu và tham chiếu giao diện: `docs/02_UI/TuVi_UI_Brief_Claude_v1.md`.
- Quy ước metadata sao: `src/catalog/README.md`.

## 9. Quy tắc quản lý trạng thái

- `verified`: khớp các fixture Tuvi.vn có trường expected tương ứng; nêu rõ phạm vi và số fixture.
- `candidate`: có công thức tham khảo nhưng chưa đủ fixture Tuvi.vn.
- `conflict`: hai hay nhiều công thức/nguồn cho kết quả khác nhau.
- `missing_rule`: chưa tìm được quy tắc đủ căn cứ.
- Không suy ra “toàn bộ engine chính xác” từ kết quả 23 bản đồ 14 chính tinh.
- Chỉ yêu cầu người dùng chụp thêm ảnh khi không thể trích dữ liệu cần thiết từ 48 fixture hiện có hoặc cần tạo cặp năm xem/điều kiện phân biệt một công thức cụ thể.
