import { solarToLunar } from '../calendar/vietnamese-lunar.js';
import { julianDayNumber } from '../calendar/julian.js';
import { dayCanChi, hourCanChi, monthCanChi, yearCanChi } from '../calendar/can-chi.js';
import { hourBranchFromTime } from '../calendar/time.js';
import { mod } from './constants.js';
import type { BirthInput, ChartCore, StarPlacement } from './types.js';
import { getMenhThanBranches, getPalaceNames, getPalaceStems } from './palaces.js';
import { getBureau } from './bureau.js';
import { getMenhChu, getThanChu } from './masters.js';
import { getThienPhuBranch, getTuViBranch, place14MainStars } from './main-stars.js';
import { placeBacSiCircle, placeDayStars, placeHoaLinh, placeHourStars, placeMonthStars, placeThaiTueCircle, placeTrangSinhCircle, placeYearBranchStars, placeYearStemStars } from './stars-secondary.js';

function parseDate(value:string):{day:number;month:number;year:number} {
  const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if(!m) throw new Error('solarDate phải có định dạng YYYY-MM-DD');
  const year=Number(m[1]),month=Number(m[2]),day=Number(m[3]);
  const d=new Date(Date.UTC(year,month-1,day));
  if(d.getUTCFullYear()!==year||d.getUTCMonth()!==month-1||d.getUTCDate()!==day) throw new Error('Ngày dương lịch không hợp lệ');
  if(year<1900||year>2100) throw new RangeError('MVP hỗ trợ năm sinh 1900–2100');
  return {day,month,year};
}
function placementMonth(month:number,day:number,isLeap:boolean):number {
  if(!isLeap) return month;
  return day<=15?month:mod(month,12)+1;
}
function addToPalaces(stars:StarPlacement[],palaceStars:Map<number,StarPlacement[]>):void {
  for(const star of stars){ const list=palaceStars.get(star.branch)??[]; list.push(star); palaceStars.set(star.branch,list); }
}
export function buildChart(input:BirthInput):ChartCore {
  if(input.gender!=='nam'&&input.gender!=='nu') throw new Error('Giới tính bắt buộc là Nam hoặc Nữ');
  const solar=parseDate(input.solarDate);
  const lunar=solarToLunar(solar.day,solar.month,solar.year,7);
  const pMonth=placementMonth(lunar.month,lunar.day,lunar.isLeapMonth);
  const jdn=julianDayNumber(solar.day,solar.month,solar.year);
  const ycc=yearCanChi(lunar.year), mcc=monthCanChi(ycc.stem,pMonth), dcc=dayCanChi(jdn);
  const unknown=input.unknownTime===true || input.hour===undefined || input.minute===undefined;
  const timeBranch=unknown?undefined:hourBranchFromTime(input.hour!,input.minute!);
  const hcc=timeBranch===undefined?undefined:hourCanChi(dcc.stem,timeBranch);
  const warnings:string[]=[];
  if(lunar.isLeapMonth) warnings.push(`Sinh tháng nhuận ${lunar.month}; tháng dùng để an sao tạm tính là ${pMonth}. Quy tắc tháng nhuận 12 ngày 16+ còn cần fixture.`);
  if(unknown) warnings.push('Không rõ giờ sinh: chưa an Mệnh/Thân, chính tinh và các sao phụ thuộc giờ. Không tự gán giờ mặc định.');
  const palaceStars=new Map<number,StarPlacement[]>();
  let menh:number|undefined,than:number|undefined,bureau:ChartCore['bureau'],tv:number|undefined,tp:number|undefined;
  if(timeBranch!==undefined){
    ({menh,than}=getMenhThanBranches(pMonth,timeBranch));
    const palaceStems=getPalaceStems(ycc.stem,menh);
    const menhStem=palaceStems[menh]!;
    const b=getBureau(menhStem,menh); bureau={number:b.number,name:b.name};
    tv=getTuViBranch(lunar.day,b.number); tp=getThienPhuBranch(tv);
    addToPalaces(place14MainStars(tv,tp).map(s=>({...s,scope:'natal' as const,status:'CANDIDATE_SPEC' as const})),palaceStars);
    const monthStars=placeMonthStars(pMonth); addToPalaces(monthStars,palaceStars);
    const hourStars=placeHourStars(timeBranch); addToPalaces(hourStars,palaceStars);
    const ta=monthStars.find(s=>s.id==='ta-phu')!.branch,huu=monthStars.find(s=>s.id==='huu-bat')!.branch;
    const vx=hourStars.find(s=>s.id==='van-xuong')!.branch,vk=hourStars.find(s=>s.id==='van-khuc')!.branch;
    addToPalaces(placeDayStars(lunar.day,ta,huu,vx,vk),palaceStars);
    addToPalaces(placeYearBranchStars(ycc.branch,menh,than),palaceStars);
    const stemStars=placeYearStemStars(ycc.stem); addToPalaces(stemStars,palaceStars);
    const locTon=stemStars.find(s=>s.id==='loc-ton')!.branch;
    const yangYear=ycc.stem%2===0;
    const direction:1|-1=((yangYear&&input.gender==='nam')||(!yangYear&&input.gender==='nu'))?1:-1;
    addToPalaces(placeBacSiCircle(locTon,direction),palaceStars);
    addToPalaces(placeTrangSinhCircle(b.number,direction),palaceStars);
    addToPalaces(placeThaiTueCircle(ycc.branch),palaceStars);
    addToPalaces(placeHoaLinh(ycc.branch,timeBranch),palaceStars);
  }
  const names=menh===undefined?Array.from({length:12},(_,branch)=>({branch,name:'Chưa xác định'})):getPalaceNames(menh);
  const stems=getPalaceStems(ycc.stem,menh??2);
  const palaces=names.map(({branch,name})=>({branch,name,stem:stems[branch]!,stars:palaceStars.get(branch)??[]}));
  return {input,lunar:{...lunar,placementMonth:pMonth},yearCanChi:ycc,monthCanChi:mcc,dayCanChi:dcc,...(hcc?{hourCanChi:hcc}:{}),...(timeBranch===undefined?{}:{timeBranch}),...(menh===undefined?{}:{menhBranch:menh}),...(than===undefined?{}:{thanBranch:than}),menhChu:getMenhChu(ycc.branch),thanChu:getThanChu(ycc.branch),...(bureau?{bureau}:{}),...(tv===undefined?{}:{tuViBranch:tv}),...(tp===undefined?{}:{thienPhuBranch:tp}),palaces,warnings};
}
