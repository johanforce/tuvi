import { mod, PALACE_NAMES } from './constants.js';
export function getMenhThanBranches(placementMonth:number,timeBranch:number):{menh:number;than:number} {
  return {menh:mod(2+(placementMonth-1)-timeBranch),than:mod(2+(placementMonth-1)+timeBranch)};
}
export function getPalaceNames(menhBranch:number):Array<{branch:number;name:string}> {
  return Array.from({length:12},(_,offset)=>({branch:mod(menhBranch+offset),name:PALACE_NAMES[offset]!}));
}
export function getPalaceStems(yearStem:number,menhBranch:number):number[] {
  const tigerStemByYearStem=[2,4,6,8,0,2,4,6,8,0]; // Bính, Mậu, Canh, Nhâm, Giáp...
  const tigerStem=tigerStemByYearStem[mod(yearStem,10)]!;
  return Array.from({length:12},(_,branch)=>mod(tigerStem+(branch-2),10));
}
