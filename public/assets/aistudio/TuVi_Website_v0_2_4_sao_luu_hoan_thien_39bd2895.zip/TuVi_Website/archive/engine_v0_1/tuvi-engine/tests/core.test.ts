import {describe,it,expect} from 'vitest';
import {hourBranchFromTime} from '../src/calendar/time.js';
import {solarToLunar} from '../src/calendar/vietnamese-lunar.js';
import {julianDayNumber} from '../src/calendar/julian.js';
import {dayCanChi,monthCanChi,yearCanChi,hourCanChi} from '../src/calendar/can-chi.js';
import {getMenhThanBranches} from '../src/engine/palaces.js';
import {getTuViBranch,getThienPhuBranch,place14MainStars} from '../src/engine/main-stars.js';
import {buildChart} from '../src/engine/build-chart.js';

describe('giờ địa chi theo quy ước dự án',()=>{
  it.each([[0,0,0],[0,59,0],[1,0,1],[10,0,5],[10,59,5],[11,0,6],[22,59,11],[23,0,0],[23,59,0]] as const)('%i:%i => chi %i',(h,m,b)=>expect(hourBranchFromTime(h,m)).toBe(b));
});
describe('lịch âm Việt Nam UTC+7',()=>{
  it('TV-001: 01/01/1911 => 02/12/1910 âm lịch',()=>expect(solarToLunar(1,1,1911,7)).toEqual({day:2,month:12,year:1910,isLeapMonth:false}));
  it('Tết 2024',()=>expect(solarToLunar(10,2,2024,7)).toEqual({day:1,month:1,year:2024,isLeapMonth:false}));
});
describe('Can Chi',()=>{
  it('TV-001: năm Canh Tuất',()=>expect(yearCanChi(1910).label).toBe('Canh Tuất'));
  it('TV-001: tháng Kỷ Sửu',()=>expect(monthCanChi(6,12).label).toBe('Kỷ Sửu'));
  it('TV-001: ngày Tân Mùi',()=>expect(dayCanChi(julianDayNumber(1,1,1911)).label).toBe('Tân Mùi'));
  it('TV-001: giờ Giáp Ngọ',()=>expect(hourCanChi(7,6).label).toBe('Giáp Ngọ'));
});
describe('an Mệnh/Thân và chính tinh',()=>{
  it('TV-001: Mệnh/Thân đồng cung Mùi',()=>expect(getMenhThanBranches(12,6)).toEqual({menh:7,than:7}));
  it('Tử Vi và Thiên Phủ luôn là 2 mốc của 14 chính tinh',()=>{
    const tv=getTuViBranch(2,3),tp=getThienPhuBranch(tv),stars=place14MainStars(tv,tp);
    expect(stars).toHaveLength(14); expect(new Set(stars.map(s=>s.id)).size).toBe(14);
  });
});
describe('buildChart',()=>{
  it('tạo chart TV-001 và không làm mất thông tin giờ',()=>{
    const chart=buildChart({gender:'nam',solarDate:'1911-01-01',hour:12,minute:30});
    expect(chart.lunar).toMatchObject({day:2,month:12,year:1910,placementMonth:12});
    expect(chart.yearCanChi.label).toBe('Canh Tuất');
    expect(chart.monthCanChi.label).toBe('Kỷ Sửu');
    expect(chart.dayCanChi.label).toBe('Tân Mùi');
    expect(chart.hourCanChi?.label).toBe('Giáp Ngọ');
    expect(chart.menhBranch).toBe(7); expect(chart.thanBranch).toBe(7);
    expect(chart.bureau?.name).toBe('Mộc Tam Cục');
    expect(chart.menhChu).toBe('Lộc Tồn'); expect(chart.thanChu).toBe('Văn Xương');
    expect(chart.palaces.reduce((n,p)=>n+p.stars.filter(s=>['tu-vi','thien-co','thai-duong','vu-khuc','thien-dong','liem-trinh','thien-phu','thai-am','tham-lang','cu-mon','thien-tuong','thien-luong','that-sat','pha-quan'].includes(s.id)).length,0)).toBe(14);
  });
  it('không rõ giờ thì không bịa Mệnh/Thân/chính tinh',()=>{
    const chart=buildChart({gender:'nu',solarDate:'2000-01-01',unknownTime:true});
    expect(chart.menhBranch).toBeUndefined(); expect(chart.thanBranch).toBeUndefined(); expect(chart.tuViBranch).toBeUndefined();
    expect(chart.warnings.length).toBeGreaterThan(0);
  });
});
