import { mod } from './constants.js';
import type { StarPlacement } from './types.js';
const p=(id:string,name:string,branch:number,status:StarPlacement['status']='CANDIDATE_SPEC',scope:'natal'|'annual'='natal'):StarPlacement=>({id,name,branch:mod(branch),status,scope});
export function placeMonthStars(month:number):StarPlacement[] {
  const m=month-1;
  return [p('ta-phu','Tả Phù',4+m,'CANDIDATE_IZTRO'),p('huu-bat','Hữu Bật',10-m,'CANDIDATE_IZTRO'),p('thien-hinh','Thiên Hình',9+m,'CANDIDATE_IZTRO'),p('thien-dieu','Thiên Diêu',1+m,'CANDIDATE_IZTRO'),p('thien-y','Thiên Y',1+m,'CONFLICT'),
    p('thien-vu','Thiên Vu',([5,8,2,11,5,8,2,11,5,8,2,11] as number[])[month-1]!,'CANDIDATE_IZTRO'),
    p('am-sat','Âm Sát',([2,0,10,8,6,4,2,0,10,8,6,4] as number[])[month-1]!,'CANDIDATE_IZTRO'),
    p('thien-nguyet','Thiên Nguyệt',([10,5,4,2,7,3,11,7,2,6,10,2] as number[])[month-1]!,'CANDIDATE_IZTRO')];
}
export function placeHourStars(hourBranch:number):StarPlacement[] {
  return [p('van-xuong','Văn Xương',10-hourBranch,'CANDIDATE_IZTRO'),p('van-khuc','Văn Khúc',4+hourBranch,'CANDIDATE_IZTRO'),p('thai-phu','Thai Phụ',6+hourBranch,'CANDIDATE_IZTRO'),p('phong-cao','Phong Cáo',2+hourBranch,'CONFLICT')];
}
export function placeDayStars(day:number,taPhuBranch:number,huuBatBranch:number,vanXuongBranch:number,vanKhucBranch:number):StarPlacement[] {
  return [p('tam-thai','Tam Thai',taPhuBranch+day-1,'CANDIDATE_IZTRO'),p('bat-toa','Bát Tọa',huuBatBranch-day+1,'CANDIDATE_IZTRO'),p('an-quang','Ân Quang',vanXuongBranch+day-2,'CANDIDATE_IZTRO'),p('thien-quy','Thiên Quý',vanKhucBranch+day-2,'CANDIDATE_IZTRO')];
}
export function placeYearBranchStars(yearBranch:number,menhBranch:number,thanBranch:number):StarPlacement[] {
  const z=yearBranch;
  const peachByBranch=[9,6,3,0,9,6,3,0,9,6,3,0];
  const hoaCaiByBranch=[4,1,10,7,4,1,10,7,4,1,10,7];
  const kiepSatByBranch=[5,2,11,8,5,2,11,8,5,2,11,8];
  const coQuaByBranch=[{c:2,q:10},{c:2,q:10},{c:5,q:1},{c:5,q:1},{c:5,q:1},{c:8,q:4},{c:8,q:4},{c:8,q:4},{c:11,q:7},{c:11,q:7},{c:11,q:7},{c:2,q:10}];
  const coQua=coQuaByBranch[z]!;
  const thienMaByBranch=[2,11,8,5,2,11,8,5,2,11,8,5];
  return [p('thien-ma','Thiên Mã',thienMaByBranch[z]!,'CANDIDATE_SPEC'),
    p('dao-hoa','Đào Hoa',peachByBranch[z]!,'CANDIDATE_IZTRO'),p('hong-loan','Hồng Loan',mod(3-z),'CANDIDATE_IZTRO'),p('thien-hy','Thiên Hỷ',mod(9-z),'CANDIDATE_IZTRO'),
    p('hoa-cai','Hoa Cái',hoaCaiByBranch[z]!,'CANDIDATE_IZTRO'),p('kiep-sat','Kiếp Sát',kiepSatByBranch[z]!,'CANDIDATE_IZTRO'),
    p('long-tri','Long Trì',4+z,'CANDIDATE_IZTRO'),p('phuong-cac','Phượng Các',10-z,'CANDIDATE_IZTRO'),p('thien-khoc','Thiên Khốc',6-z,'CANDIDATE_IZTRO'),p('thien-hu','Thiên Hư',6+z,'CANDIDATE_IZTRO'),
    p('thien-duc','Thiên Đức',9+z,'CANDIDATE_IZTRO'),p('nguyet-duc','Nguyệt Đức',5+z,'CANDIDATE_IZTRO'),p('thien-khong','Thiên Không',z+1,'CANDIDATE_IZTRO'),
    p('thien-tai','Thiên Tài',menhBranch+z,'CANDIDATE_IZTRO'),p('thien-tho','Thiên Thọ',thanBranch+z,'CANDIDATE_IZTRO'),
    p('co-than','Cô Thần',coQua.c,'CANDIDATE_IZTRO'),p('qua-tu','Quả Tú',coQua.q,'CANDIDATE_IZTRO')];
}
export function placeYearStemStars(yearStem:number):StarPlacement[] {
  const quan=[7,4,5,2,3,9,11,9,10,6];
  const phuc=[9,8,0,11,3,2,6,5,6,5];
  const trù=[5,6,0,5,6,8,2,6,9,11];
  const luuHa=[9,10,7,4,5,6,8,3,11,2];
  const locTon=[2,3,5,6,5,6,8,9,11,0];
  return [p('loc-ton','Lộc Tồn',locTon[yearStem]!,'CANDIDATE_SPEC'),p('thien-quan','Thiên Quan',quan[yearStem]!,'CANDIDATE_SPEC'),p('thien-phuc','Thiên Phúc',phuc[yearStem]!,'CANDIDATE_SPEC'),p('thien-tru','Thiên Trù',trù[yearStem]!,'CONFLICT'),p('luu-ha','Lưu Hà',luuHa[yearStem]!,'CANDIDATE_SPEC')];
}

const BAC_SI_NAMES=['Bác Sĩ','Lực Sĩ','Thanh Long','Tiểu Hao','Tướng Quân','Tấu Thư','Phi Liêm','Hỷ Thần','Bệnh Phù','Đại Hao','Phục Binh','Quan Phủ'];
const TRANG_SINH_NAMES=['Tràng Sinh','Mộc Dục','Quan Đới','Lâm Quan','Đế Vượng','Suy','Bệnh','Tử','Mộ','Tuyệt','Thai','Dưỡng'];
const THAI_TUE_NAMES=['Thái Tuế','Thiếu Dương','Tang Môn','Thiếu Âm','Quan Phù','Tử Phù','Tuế Phá','Long Đức','Bạch Hổ','Phúc Đức','Điếu Khách','Trực Phù'];
const TRANG_SINH_START:Record<number,number>={2:8,3:11,4:5,5:8,6:2};
export function placeBacSiCircle(locTonBranch:number,direction:1|-1):StarPlacement[] {
  return BAC_SI_NAMES.map((name,i)=>p(`bac-si-${i}`,name,locTonBranch+direction*i,'CANDIDATE_SPEC'));
}
export function placeTrangSinhCircle(bureauNumber:number,direction:1|-1):StarPlacement[] {
  const start=TRANG_SINH_START[bureauNumber];
  if(start===undefined) throw new Error(`Cục không hợp lệ: ${bureauNumber}`);
  return TRANG_SINH_NAMES.map((name,i)=>p(`trang-sinh-${i}`,name,start+direction*i,'CANDIDATE_SPEC'));
}
export function placeThaiTueCircle(yearBranch:number):StarPlacement[] {
  return THAI_TUE_NAMES.map((name,i)=>p(`thai-tue-${i}`,name,yearBranch+i,'CANDIDATE_SPEC'));
}
export function placeHoaLinh(yearBranch:number,hourBranch:number):StarPlacement[] {
  const group=Math.floor(yearBranch/3);
  const hoaStart=[1,2,3,9][group]!;
  const linhStart=[3,10,10,10][group]!;
  // Both directions follow the candidate formula in v1.3; unresolved against Tuvi.vn.
  return [p('hoa-tinh','Hỏa Tinh',hoaStart+hourBranch,'CONFLICT'),p('linh-tinh','Linh Tinh',linhStart+hourBranch,'CONFLICT')];
}
